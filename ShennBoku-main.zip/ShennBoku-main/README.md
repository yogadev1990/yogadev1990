# Hi there 👋,  <br> I'm Afdhalul Ichsan Yourdan
![I'm Afdhalul Ichsan Yourdan](https://raw.githubusercontent.com/ShennBoku/ShennBoku/main/Shennboku.png)

## Information

I'm a Junior Full Stack Web and FiveM Server Developer, currently learning other programming languages like Python, NodeJS, LUA, etc.
- 🔭 I'm currently lead on [ShennX Network](https://shennx.net/) 
- 🌱 I'm currently developing a FiveM (GTA V) server for [iCONIC RP Indonesia](https://iconicroleplay.id/)
- 💼 I'm pursuing a Bachelor of Informatics Engineering degree
- 📫 How to reach me: afdhalul@shenn.id 


## Currently listening to

<a href="https://volt.fm/ShennBoku" target="_blank"><img src="https://spotify-nowplay-badge-shennboku.vercel.app/api/now-playing.svg" width="540" height="52" alt="now playing"></a>

  
## Github Stats

<details> 
  <summary><b>💻 GitHub Profile Stats</b></summary>
  <br/>
  <p align="center">
      <a href="https://github.com/anuraghazra/github-readme-stats"><img alt="ShennBoku's Github Stats" src="https://github-readme-stats.vercel.app/api?username=ShennBoku&show_icons=true&count_private=true&theme=algolia" height="192px"/></a>
      <br/>
      <sup><sub><b>Note:</b> Top languages is only a metric of the languages my public code consists of and doesn't reflect experience or skill level.</sub></sup>
  </p>
</details>
<details>
  <summary><b>⚡ Most Used Language</b></summary>
  <br/>
  <p align="center">
      <img src="https://github-readme-stats.vercel.app/api/top-langs?username=ShennBoku&show_icons=true&locale=en&layout=compact&theme=algolia" alt="Most used language" height="192px"/>
  </p>
</details>


## Let's Connect

<p align="center">
    <a href="mailto:afdhalul@shenn.id" target="BLANK"><img src="https://raw.githubusercontent.com/ShennBoku/ShennBoku/main/assets/images/icons8-bubbles-gmail.png" alt="Gmail"/></a>
    <a href="https://github.com/ShennBoku"><img src="https://raw.githubusercontent.com/ShennBoku/ShennBoku/main/assets/images/icons8-bubbles-github.png" alt="Github"/></a>
	<a href="https://dev.to/ShennBoku" target="BLANK"><img src="https://raw.githubusercontent.com/ShennBoku/ShennBoku/main/assets/images/icons8-bubbles-dev.png" alt="dev.to"/></a>
	<a href="https://linkedin.com/in/afdhalul-ichsan-yourdan" target="BLANK"><img src="https://raw.githubusercontent.com/ShennBoku/ShennBoku/main/assets/images/icons8-bubbles-linkedin.png" alt="LinkedIn"/></a>
	<a href="https://facebook.com/ShennBoku" target="BLANK"><img src="https://raw.githubusercontent.com/ShennBoku/ShennBoku/main/assets/images/icons8-bubbles-facebook.png" alt="Facebook"/></a>
	<a href="https://instagram.com/ShennBoku/" target="BLANK"><img src="https://raw.githubusercontent.com/ShennBoku/ShennBoku/main/assets/images/icons8-bubbles-instagram.png" alt="Instagram"/></a>
	<a href="https://twitter.com/ShennBoku" target="BLANK"><img src="https://raw.githubusercontent.com/ShennBoku/ShennBoku/main/assets/images/icons8-bubbles-twitter.png" alt="Twitter"/></a>
	<a href="https://youtube.com/@ShennBoku" target="BLANK"><img src="https://raw.githubusercontent.com/ShennBoku/ShennBoku/main/assets/images/icons8-bubbles-youtube.png" alt="Youtube"/></a>
	<a href="https://www.shenn.id/" target="BLANK"><img src="https://raw.githubusercontent.com/ShennBoku/ShennBoku/main/assets/images/icons8-bubbles-extlink.png" alt="Website"/></a>
</p>
